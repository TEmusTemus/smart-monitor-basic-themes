# Fallout Landscape Theme for Turing 3.5-inch Smart Monitor

Fallout/Pip-Boy inspired 480x320 landscape theme for Smart Monitor Basic.

## Contents

- `Fallout_landscape.ui` — native Smart Monitor Basic UI, including the latest saved widget layout
- `config.ini` — theme startup image settings
- `images/` — Fallout background, startup frames, and native theme assets

The startup frames `X0.jpg` through `X4.jpg` are identical so the monitor does not rotate back to the original template artwork during startup.

## Install

1. Back up the existing theme folder.
2. Copy the contents of this folder into the target theme folder.
3. Set Smart Monitor Basic's target UI to `Fallout_landscape.ui`.
4. Keep the monitor at its native 480x320 landscape orientation.

The labels and panel artwork are part of the Fallout background. Live values remain native Smart Monitor Basic widgets and can be repositioned independently in the editor.
